package com.jike.demo.controller;


import com.jike.demo.pojo.TbStudent;
import com.jike.demo.service.TbStudentService;
import com.jike.demo.vo.Result;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.security.PublicKey;


/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Cyp123
 * @since 2023-02-09
 */
@Controller
@RequestMapping("/tbStudent")
@MapperScan("com.jike.demo.dao")
public class TbStudentController {

    @Autowired
    private TbStudentService tbStudentService;


    @GetMapping("/index.html")
    public String toIndex(){
        return "index";
    }

    @ResponseBody
    @PostMapping("/save")
    public Result insert(@RequestBody TbStudent student){

        if (tbStudentService.save(student)){
            return Result.success();
        }else {
            return Result.error("失败");
        }
    }
}

