package com.jike.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jike.demo.pojo.TbStudent;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Cyp123
 * @since 2023-02-09
 */
public interface TbStudentService extends IService<TbStudent> {

}
